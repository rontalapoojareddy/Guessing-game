import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class pancard 
{
    public static void main(String args[]) 
	{
        new pancard();
    }

    JFrame frame;
    JTextField numberField;
    JLabel validLabel;
    JButton verifyButton;

    public pancard() 
	{
        frame = new JFrame("Pancard Number Verifier");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(350, 400));
        numberField = new JTextField(10);
        validLabel = new JLabel("not yet verified");
        verifyButton = new JButton("Verify Pancard Number");
        verifyButton.addActionListener(new VerifyListener());

        frame.setLayout(new FlowLayout());
        frame.add(numberField);
        frame.add(verifyButton);
        frame.add(validLabel);
        frame.setVisible(true);
    }

    public static boolean IsValidPanCardNumber(String number) 
	{
        
        if (number.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}") && !hasAlphabetsInOrder(number) && !hasNumbersInOrder(number)) 
		{
            return true;
        } 
		else 
		{
            return false;
        }
    }

    
    public static boolean hasAlphabetsInOrder(String number) 
	{
        for (int i = 0; i < number.length() - 1 - 4; i++) 
		{
            if (number.substring(i, i + 5).matches("[A-Z]{5}")) 
			{
                return true;
            }
        }
        return false;
    }

    
    public static boolean hasNumbersInOrder(String number) 
	{
        for (int i = 0; i < number.length() - 1 - 3; i++) 
		{
            if (number.substring(i, i + 4).matches("[0-9]{4}")) 
			{
                String sub = number.substring(i, i + 4);
                int firstDigit = Character.getNumericValue(sub.charAt(0));
                int lastDigit = Character.getNumericValue(sub.charAt(3));
                if (lastDigit - firstDigit == 3) 
				{
                    return true;
                }
            }
        }
        return false;
    }

    class VerifyListener implements ActionListener 
	{
        public void actionPerformed(ActionEvent event) 
		{
            String number = numberField.getText().toUpperCase(); 
            if (IsValidPanCardNumber(number)) 
			{
                validLabel.setText("Valid number!");
            } 
			else 
			{
                validLabel.setText("Invalid number.");
            }
        }
    }
}
